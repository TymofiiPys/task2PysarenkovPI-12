#pragma once

namespace maze {
	struct NodeList {
	private:
		struct mazenode {
			int x;
			int y;
			bool junc;
			int dir;
			mazenode* next;
			mazenode(int x, int y, bool junc);
		};
	private:
		void searchAndPrintPath();
	};
}